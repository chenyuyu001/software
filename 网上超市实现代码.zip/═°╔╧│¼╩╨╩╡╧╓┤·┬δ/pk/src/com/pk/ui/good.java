package com.pk.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;

import com.pk.control.GoodsListControl;
import com.pk.dao.Goodslist;
import com.pk.dao.GoodslistDAO;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class good extends JFrame {

	private JPanel contentPane;
	private JTable table;
	public static List list;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
	
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					good frame = new good();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public good() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 362, 335);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 228, 181));
		panel.setBounds(5, 5, 345, 291);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(23, 26, 186, 224);
		panel.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
			},
			new String[] {
				"���", "��Ʒ", "�۸�"
			}
		));
		scrollPane.setViewportView(table);
		Initialtable();
		JButton btnNewButton = new JButton("\u5220\u9664\u5546\u54C1");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel tableModel = (DefaultTableModel) getTable().getModel();
				if(getTable().getSelectedRowCount() == 0)
				{
					JOptionPane.showConfirmDialog(null, "��ѡ��Ҫɾ���ļ�¼!","��ʾ", JOptionPane.CLOSED_OPTION);
				}
				else if(getTable().getSelectedRowCount() > 0)
				{
					int choice = JOptionPane.showConfirmDialog(null, "ѡ�еļ�¼����ɾ��!","�Ƿ�ɾ��:", JOptionPane.OK_CANCEL_OPTION);
					if(choice == 0)
					{
						for(int i = getTable().getSelectedRow();i < (getTable().getSelectedRow() +
								getTable().getSelectedRowCount());i++)
						{	
							tableModel.removeRow(i);
							GoodsListControl.getGoodsListControl().delete((Goodslist)list.get(i));
						}
					}
					Initialtable();
				}
				
			}
			
		});
		btnNewButton.setBounds(234, 74, 93, 54);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u6DFB\u52A0\u5546\u54C1");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addGoods addgoods= new addGoods();
				addgoods.skip();
				dispose();
			}
		});
		btnNewButton_1.setBounds(234, 165, 93, 47);
		panel.add(btnNewButton_1);
	}
	public void Initialtable()
	{
		DefaultTableModel tableModel = (DefaultTableModel) getTable().getModel();
		if(tableModel.getRowCount() != 0)
		{
			tableModel.setRowCount(0);
		}
		list = GoodsListControl.getGoodsListControl().findALL();	

		for(int i = 0;i < list.size();i++)
		{
			Goodslist goodslist = (Goodslist)list.get(i);
			
			tableModel.addRow(new Object[] {
				goodslist.getGoodId().toString(),goodslist.getGoodName().toString(),
				goodslist.getGoodPrice().toString()});
		}
	}
	public JTable getTable() {
		return table;
	}
	public void skip()
	{
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					good frame = new good();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}
}
