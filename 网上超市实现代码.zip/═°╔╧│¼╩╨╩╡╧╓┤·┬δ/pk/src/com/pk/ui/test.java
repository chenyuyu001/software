package com.pk.ui;

import com.pk.dao.Goodslist;
import com.pk.dao.GoodslistDAO;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Goodslist s=new Goodslist(5, "chen", 12.0);
		GoodslistDAO a =new GoodslistDAO();
		a.save(s);
	}
}

