package com.pk.control;
import java.util.List;

import org.hibernate.Session;




import com.pk.factory.HibernateSessionFactory;
import com.pk.dao.Goodslist;
import com.pk.dao.GoodslistDAO;


public class GoodsListControl {
	private static GoodsListControl control = null; 
	public static GoodsListControl getGoodsListControl(){
		if(null==control){
			control = new GoodsListControl();
		}
		return control;
	}
	

	private GoodslistDAO  GoodslistDAO = null;
	private Session session = null;
	
	private GoodsListControl(){
		GoodslistDAO = new GoodslistDAO();
		session = HibernateSessionFactory.getSession();
	}
	

	public Goodslist save(int GoodId, String GoodName, double GoodPrice
		){
		Goodslist staff = new Goodslist(GoodId,  GoodName, GoodPrice
				);
		GoodslistDAO.save(staff);
		session.beginTransaction().commit();
		session.flush();
		return staff;
	}
    
	public Goodslist findById(int id){
		
		try {
			Goodslist goodslist = GoodslistDAO.findById(id);
			return goodslist;
		} catch (Exception e) {
			return null;
		}
	}
	public List findByGoodName(String GoodName)
	{
		try
		{
			return GoodslistDAO.findByGoodName(GoodName);
		}
		catch(Exception e)
		{
			return null;
		}
	}
	
	public List findByGoodPrice(double price)
	{
		try
		{
			return GoodslistDAO.findByGoodPrice(price);
		}
		catch(Exception e)
		{
			return null;
		}
	}
	public List findALL()
	{
		return GoodslistDAO.findAll();
	}
	public Boolean delete(Goodslist goodslist) {
		try {

			GoodslistDAO.delete(goodslist);
			session.beginTransaction().commit();
			session.flush();
			return true;

		} catch (Exception e) {
			return false;
		}
	}
	public Boolean merge(Goodslist goodslist) {
		try {

			GoodslistDAO.merge(goodslist);
			session.beginTransaction().commit();
			session.flush();
			return true;

		} catch (Exception e) {
			return false;
		}
	}
}
