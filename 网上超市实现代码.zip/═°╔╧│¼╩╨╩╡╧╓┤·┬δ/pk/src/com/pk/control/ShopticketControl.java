package com.pk.control;
import java.util.List;

import org.hibernate.Session;





import com.pk.factory.HibernateSessionFactory;
import com.pk.dao.ShopticketDAO;
import com.pk.dao.Shopticket;
public class ShopticketControl {
	private static ShopticketControl control = null; 
	public static ShopticketControl getShopticketControl(){
		if(null==control){
			control = new ShopticketControl();
		}
		return control;
	}
	

	private ShopticketDAO  ShopticketDAO = null;
	private Session session = null;
	
	private ShopticketControl(){
		ShopticketDAO = new ShopticketDAO();
		session = HibernateSessionFactory.getSession();
	}
	

	public Shopticket save(int Num,int GoodId, String GoodName, double GoodPrice
		){
		Shopticket shop = new Shopticket(Num,GoodId,  GoodName, GoodPrice
				);
		ShopticketDAO.save(shop);
		session.beginTransaction().commit();
		session.flush();
		return shop;
	}
    
	public Shopticket findById(int id){
		
		try {
			Shopticket shopticket = ShopticketDAO.findById(id);
			return shopticket;
		} catch (Exception e) {
			return null;
		}
	}
	public List findByGoodName(String GoodName)
	{
		try
		{
			return ShopticketDAO.findByGoodName(GoodName);
		}
		catch(Exception e)
		{
			return null;
		}
	}
	
	public List findByGoodPrice(double price)
	{
		try
		{
			return ShopticketDAO.findByGoodPrice(price);
		}
		catch(Exception e)
		{
			return null;
		}
	}
	
	
	
	
	
	
	
	public List findALL()
	{
		return ShopticketDAO.findAll();
	}
	public Boolean delete(Shopticket shopticket) {
		try {

			ShopticketDAO.delete(shopticket);
			session.beginTransaction().commit();
			session.flush();
			return true;

		} catch (Exception e) {
			return false;
		}
	}
	
	
	public Boolean merge(Shopticket shopticket) {
		try {

			ShopticketDAO.merge(shopticket);
			session.beginTransaction().commit();
			session.flush();
			return true;

		} catch (Exception e) {
			return false;
		}
	}
}

