package com.pk.ui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;





import com.pk.control.GoodsListControl;
import com.pk.control.ShopticketControl;
import com.pk.dao.Goodslist;
import com.pk.dao.Shopticket;
import com.pk.dao.ShopticketDAO;
import javax.swing.JLabel;
import java.awt.event.MouseMotionAdapter;
import javax.swing.JTextArea;
import java.awt.Font;
import java.awt.Color;



public class shop extends JFrame {

	private JPanel contentPane;
	private JTable table;
	public static List list;
	private JTable table_1;
	static double sum=0.0;
	private JLabel lblNewLabel;
	static int number=0;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					shop frame = new shop();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public shop() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 475, 351);
		contentPane = new JPanel();
		contentPane.setBackground(Color.ORANGE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(24, 43, 199, 220);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(0, 0, 199, 220);
		panel.add(scrollPane_2);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel table1 = (DefaultTableModel) table_1
						.getModel();
				if (e.getClickCount() >=1) {

					int rowI = table.rowAtPoint(e.getPoint());// �õ�table���к�
					table1.addRow(new Object[] {
							table.getModel().getValueAt(rowI, 0),
							table.getModel().getValueAt(rowI, 1),
							table.getModel().getValueAt(rowI, 2)

							 });

					System.out.println("˫����� "
							+ table.getModel().getValueAt(rowI, 0));
				}
				String goodsID;
				
				int rowCount = table1.getRowCount();
			//	for (int i = 0; i < rowCount; i++) {
					goodsID = (String) table1.getValueAt(rowCount-1,0);
					int a = Integer.parseInt(goodsID);
					sum+= GoodsListControl.getGoodsListControl().findById(a).getGoodPrice();
					number++;
				// System.out.println();

			}
		});
		
//		if(e.getClickCount() == 1){
					
//			int row = table.getSelectedRow();	
//			DefaultTableModel tableModel = (DefaultTableModel) getTable().getModel();
//			list=GoodsListControl.getGoodsListControl().findALL();

//				Goodslist goodslist=(Goodslist)list.get(row);
//				int id=goodslist.getGoodId();
//				String name=goodslist.getGoodName();
//				double price=goodslist.getGoodPrice();
						
//				ShopticketControl.getShopticketControl().save(id,name,price);
//				InitialTable1();
				
					//	 Goodslist goodslist =GoodsListControl.getGoodsListControl().findById((int)(getTable().getModel().getValueAt(row,0)));
					//	 int id=goodslist.getGoodId();
					//	 String name=goodslist.getGoodName();
					//ouble price=goodslist.getGoodPrice();	 
					//efaultTableModel tableModel = (DefaultTableModel) getTable().getModel();
					//ableModel.addRow(new Object[] {
					//	id,name,price});
					//ShopticketControl.getShopticketControl().save(id,name,price);
						
					//	InitialTable1();

			        
//		}
//	}
//});
		scrollPane_2.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
				{null, null, null},
				{null, null, null},
			},
			new String[] {
				"��Ʒ���", "��Ʒ����", "��Ʒ�۸�"
			}
		));
		
		JButton btnNewButton = new JButton("\u663E\u793A\u603B\u4EF7");
		btnNewButton.setFont(new Font("΢���ź�", Font.BOLD, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
	
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				
					
					
			//	}
			//	sum= TotalCost();
			//	number++;
				lblNewLabel.setText(Double.toString(sum));
			}
		});
		
		btnNewButton.setBounds(24, 273, 94, 27);
		contentPane.add(btnNewButton);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(259, 26, 190, 225);
		contentPane.add(scrollPane_3);
		
		table_1 = new JTable();
		table_1.addMouseListener(new MouseAdapter() { // ˫��ɾ��һ��
					@Override
					public void mouseClicked(MouseEvent e) {
						

					}
				});
		
		
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u5546\u54C1\u7F16\u53F7", "\u5546\u54C1\u540D\u79F0", "\u5546\u54C1\u4EF7\u683C"
			}
		));
		scrollPane_3.setViewportView(table_1);
		
		lblNewLabel = new JLabel();
	//	lblNewLabel.setText(Double.toString(sum));
		lblNewLabel.setBounds(410, 271, 39, 27);
		contentPane.add(lblNewLabel);
		
		JButton button = new JButton("\u5220\u9664\u8BE5\u7269\u54C1");
		button.setFont(new Font("΢���ź�", Font.BOLD, 12));
		
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String goodsID;
				if (e.getClickCount() ==1) {

					DefaultTableModel table1 = (DefaultTableModel) table_1
							.getModel();

					int rowI = table_1.rowAtPoint(e.getPoint());// �õ�table���к�
					goodsID = (String) table1.getValueAt(rowI,0);
					int a = Integer.parseInt(goodsID);
					sum-= GoodsListControl.getGoodsListControl().findById(a).getGoodPrice();
					System.out.print(sum);
					table1.removeRow(rowI);
					lblNewLabel.setText(Double.toString(sum));
					number--;
				}
			}
		});
		button.setBounds(134, 272, 101, 29);
		contentPane.add(button);
		
		JButton btnNewButton_1 = new JButton("\u786E\u5B9A\u9009\u8D2D");
		btnNewButton_1.setFont(new Font("΢���ź�", Font.BOLD, 12));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
//				if(e.getClickCount() == 1){
				
//				int row = table.getSelectedRow();	
//				DefaultTableModel tableModel = (DefaultTableModel) getTable().getModel();
//				list=GoodsListControl.getGoodsListControl().findALL();
				int b=number;
				System.out.print(b);
				for (int i = 1; i <= b; i++) {
					table_1.getModel().getValueAt(i-1, 0);
					table_1.getModel().getValueAt(i-1, 1);
					table_1.getModel().getValueAt(i-1, 2);
					int id=Integer.parseInt(String.valueOf(table_1.getModel().getValueAt(i-1, 0)));
					String name=String.valueOf(table_1.getModel().getValueAt(i-1, 1));
					double price=Double.parseDouble(table_1.getModel().getValueAt(i-1, 2).toString()); 

				
			//	Goodslist goodslist=(Goodslist)list.get(i-1);
			//		int id=goodslist.getGoodId();
			//		String name=goodslist.getGoodName();
			//		double price=goodslist.getGoodPrice();							
					ShopticketControl.getShopticketControl().save(i,id,name,price);
					InitialTable1();
					
				}
				JOptionPane j=new JOptionPane();
				if (b > 0) {
					j.showMessageDialog(null, "����ɹ���", "��ʾ:",JOptionPane.CLOSED_OPTION);
				}
				else
				{
//					j.showConfirmDialog(null, "��ѡ����Ʒ��", "��ʾ:",
//							JOptionPane.CLOSED_OPTION);
					
					j.showMessageDialog(null, "��ѡ����Ʒ��", "��ʾ:",JOptionPane.CLOSED_OPTION);
				
				}
			}
		});
		btnNewButton_1.setBounds(258, 275, 93, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("\u7BA1\u7406\u5458\u754C\u9762");
		btnNewButton_2.setFont(new Font("΢���ź�", Font.BOLD, 12));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				good g=new good();
				g.skip();
				dispose();
			}
		});
		btnNewButton_2.setBounds(24, 10, 103, 23);
		contentPane.add(btnNewButton_2);
		
		JLabel lblNewLabel_1 = new JLabel("\u603B\u4EF7\u4E3A");
		lblNewLabel_1.setFont(new Font("΢���ź�", Font.BOLD, 12));
		lblNewLabel_1.setBounds(361, 271, 39, 27);
		contentPane.add(lblNewLabel_1);
		
		InitialTable();
		
		JScrollPane scrollPane_1 = new JScrollPane();
		
		JScrollPane scrollPane = new JScrollPane();
		
		
}
	public void InitialTable()
	{
		DefaultTableModel tableModel = (DefaultTableModel) getTable().getModel();
		if(tableModel.getRowCount() != 0)
		{
			tableModel.setRowCount(0);
		}
		list = GoodsListControl.getGoodsListControl().findALL();	
		String role;
		for(int i = 0;i < list.size();i++)
		{
			Goodslist goodslist = (Goodslist)list.get(i);
			
			tableModel.addRow(new Object[] {
				goodslist.getGoodId().toString(),goodslist.getGoodName().toString(),
				goodslist.getGoodPrice().toString()});
		}
	}

	public JTable getTable1() {
		return table_1;
	}
	
	public void InitialTable1()
	{
		DefaultTableModel tableModel = (DefaultTableModel) getTable().getModel();
		if(tableModel.getRowCount() != 0)
		{
			tableModel.setRowCount(0);
		}
		list = GoodsListControl.getGoodsListControl().findALL();	

		for(int i = 0;i < list.size();i++)
		{
			Goodslist goodslist = (Goodslist)list.get(i);
			
			tableModel.addRow(new Object[] {
				goodslist.getGoodId().toString(),goodslist.getGoodName().toString(),
				goodslist.getGoodPrice().toString()});
		}
		
	}
	public JTable getTable() {
		return table;
	}
	public double TotalCost(){
		double total=0.0;
		
		return total;
	}
	public void skip()
	{
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					shop frame = new shop();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
