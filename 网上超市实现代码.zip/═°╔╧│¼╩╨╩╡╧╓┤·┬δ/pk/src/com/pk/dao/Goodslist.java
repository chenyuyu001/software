package com.pk.dao;

/**
 * Goodslist entity. @author MyEclipse Persistence Tools
 */

public class Goodslist implements java.io.Serializable {

	// Fields

	private Integer goodId;
	private String goodName;
	private Double goodPrice;

	// Constructors

	/** default constructor */
	public Goodslist() {
	}

	/** minimal constructor */
	public Goodslist(Integer goodId) {
		this.goodId = goodId;
	}

	/** full constructor */
	public Goodslist(Integer goodId, String goodName, Double goodPrice) {
		this.goodId = goodId;
		this.goodName = goodName;
		this.goodPrice = goodPrice;
	}

	// Property accessors

	public Integer getGoodId() {
		return this.goodId;
	}

	public void setGoodId(Integer goodId) {
		this.goodId = goodId;
	}

	public String getGoodName() {
		return this.goodName;
	}

	public void setGoodName(String goodName) {
		this.goodName = goodName;
	}

	public Double getGoodPrice() {
		return this.goodPrice;
	}

	public void setGoodPrice(Double goodPrice) {
		this.goodPrice = goodPrice;
	}

}