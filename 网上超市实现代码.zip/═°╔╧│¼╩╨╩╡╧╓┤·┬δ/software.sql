/*
Navicat MySQL Data Transfer

Source Server         : software
Source Server Version : 50515
Source Host           : localhost:3306
Source Database       : software

Target Server Type    : MYSQL
Target Server Version : 50515
File Encoding         : 65001

Date: 2015-05-28 15:19:56
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for goodslist
-- ----------------------------
DROP TABLE IF EXISTS `goodslist`;
CREATE TABLE `goodslist` (
  `GoodID` int(11) NOT NULL,
  `GoodName` varchar(255) DEFAULT NULL,
  `GoodPrice` double DEFAULT NULL,
  PRIMARY KEY (`GoodID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of goodslist
-- ----------------------------
INSERT INTO `goodslist` VALUES ('1', '水', '12');
INSERT INTO `goodslist` VALUES ('2', '面包', '10');
INSERT INTO `goodslist` VALUES ('17', '红茶', '5');

-- ----------------------------
-- Table structure for shopticket
-- ----------------------------
DROP TABLE IF EXISTS `shopticket`;
CREATE TABLE `shopticket` (
  `Num` int(11) NOT NULL,
  `GoodID` int(11) DEFAULT NULL,
  `GoodName` varchar(255) DEFAULT NULL,
  `GoodPrice` double(10,0) DEFAULT NULL,
  PRIMARY KEY (`Num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of shopticket
-- ----------------------------
INSERT INTO `shopticket` VALUES ('1', '2', '面包', '10');
INSERT INTO `shopticket` VALUES ('2', '19', '方便面', '5');
INSERT INTO `shopticket` VALUES ('3', '1', '水', '12');
