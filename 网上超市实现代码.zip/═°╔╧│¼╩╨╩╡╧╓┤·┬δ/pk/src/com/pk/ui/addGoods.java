package com.pk.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;

import com.pk.control.GoodsListControl;
import com.pk.dao.Goodslist;
import com.pk.dao.GoodslistDAO;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;

public class addGoods extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					addGoods frame = new addGoods();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public addGoods() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 292, 319);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(240, 230, 140));
		panel.setBounds(5, 0, 271, 280);
		contentPane.add(panel);
		panel.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(131, 35, 66, 21);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(131, 91, 66, 21);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(131, 145, 66, 21);
		
		panel.add(textField_2);
		textField_2.setColumns(10);
		
		JButton btnNewButton = new JButton("\u786E\u5B9A\u6DFB\u52A0");
		btnNewButton.setFont(new Font("΢���ź�", Font.BOLD, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int id ;
				try
				{
					id = Integer.parseInt(textField.getText());
				}
				catch(Exception b)
				{
					JOptionPane.showConfirmDialog(null, "����Ϊ����","��ʾ:", JOptionPane.CLOSED_OPTION);
					return;
				}
				String name = textField_1.getText();
				double price = 0;
				try
				{
				  price = Double.parseDouble(textField_2.getText());
				  
				  
				}
				catch(Exception a)
				{
					JOptionPane.showConfirmDialog(null, "����Ϊ������","��ʾ:", JOptionPane.CLOSED_OPTION);
					return;
				}
				int count = 0;
				if(price<=0.0){
					  JOptionPane.showConfirmDialog(null, "���۴���0","��ʾ:", JOptionPane.CLOSED_OPTION);
				 }
				else{
					
				
				Goodslist temp = new Goodslist(id, name, price);
				GoodslistDAO b = new GoodslistDAO();
				b.save(temp);
				//GoodsListControl.getGoodsListControl().update(temp);
				}
			}
		});
		btnNewButton.setBounds(134, 191, 93, 37);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("\u5546\u54C1\u7F16\u53F7");
		lblNewLabel.setFont(new Font("΢���ź�", Font.BOLD, 12));
		lblNewLabel.setBounds(36, 38, 54, 15);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u5546\u54C1\u540D\u79F0");
		lblNewLabel_1.setFont(new Font("������", Font.BOLD, 12));
		lblNewLabel_1.setBounds(36, 91, 54, 15);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u5546\u54C1\u4EF7\u683C");
		lblNewLabel_2.setFont(new Font("΢���ź�", Font.BOLD, 12));
		lblNewLabel_2.setBounds(36, 148, 54, 15);
		panel.add(lblNewLabel_2);
		
		JButton btnNewButton_1 = new JButton("\u56DE\u5230\u4E3B\u754C\u9762");
		btnNewButton_1.setFont(new Font("΢���ź�", Font.BOLD, 12));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				shop s=new shop();
				s.skip();
				dispose();
			}
		});
		btnNewButton_1.setBounds(23, 191, 103, 37);
		panel.add(btnNewButton_1);
	}
	public void skip()
	{
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					addGoods frame = new addGoods();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
