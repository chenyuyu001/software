package com.pk.dao;

/**
 * Shopticket entity. @author MyEclipse Persistence Tools
 */

public class Shopticket implements java.io.Serializable {

	// Fields

	private Integer num;
	private Integer goodId;
	private String goodName;
	private Double goodPrice;

	// Constructors

	/** default constructor */
	public Shopticket() {
	}

	/** minimal constructor */
	public Shopticket(Integer num) {
		this.num = num;
	}

	/** full constructor */
	public Shopticket(Integer num, Integer goodId, String goodName,
			Double goodPrice) {
		this.num = num;
		this.goodId = goodId;
		this.goodName = goodName;
		this.goodPrice = goodPrice;
	}

	// Property accessors

	public Integer getNum() {
		return this.num;
	}

	public void setNum(Integer num) {
		this.num = num;
	}

	public Integer getGoodId() {
		return this.goodId;
	}

	public void setGoodId(Integer goodId) {
		this.goodId = goodId;
	}

	public String getGoodName() {
		return this.goodName;
	}

	public void setGoodName(String goodName) {
		this.goodName = goodName;
	}

	public Double getGoodPrice() {
		return this.goodPrice;
	}

	public void setGoodPrice(Double goodPrice) {
		this.goodPrice = goodPrice;
	}

}